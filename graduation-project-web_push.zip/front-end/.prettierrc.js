/*
1. ctrl + shift + p
2. format document with..
3. config default formatter
4. prettier 선택
*/
module.exports = {
  singleQuote: true,
  jsxSingleQuote: true,
  jsxBracketSameLine: true,
  semi: true,
  useTabs: false,
  // printWidth: 80,
  tabWidth: 2,
  trailingComma: 'all',
};
