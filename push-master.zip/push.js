/*  * npm install web-push --save
    install 해야 node push.js 사용하여
    publicKey, privateKey 데이터 얻어올 수 있음
    아래의 publicKey, privateKey는 firebase 프로젝트 > 클라우드 메시징의 웹 푸시 인증서 > 키 쌍
    let vapidKeys = {
        publicKey: 'BLzYiBM0EuFuLmzj_tDO5JpPICJqQj9qXNhPpxnDlytUq-9ET715c7B_KhnvvJJuMpPp8lbl96hu9SKsPWdhobE',
        privateKey: 'RKd2Vxw8g0nYDDAAlqE3ihQNoPrW06hn3cVdTQdpKfI'
    }

    * 수정 후,
    git commit -am "fix"
    git push
*/
const push = require('web-push');
/*
let vapidKeys = push.generateVAPIDKeys();
console.log(vapidKeys);

node push.js > publicKey, privateKey 데이터 얻을 수 있음.
*/

const vapidKeys = {
    publicKey: 'BBPryHb6u-ClL2A-5StqLTHr3LN-cllnIRbjIljNLzrZDOioCaWCUTjYFiJYx2h2Ur8bcOReV7ZWxrWWMQSP6H0',
    privateKey: 'OjfWupytjM0LIZzoqsvUO73LC0wnQo1F4aLYG_97kqw'
};

push.setVapidDetails('mailto:khj98827@gmail.com', vapidKeys.publicKey, vapidKeys.privateKey);

// Subscribe로 얻어낸 endpoint 데이터베이스 paste
const pushSubscription = { 
    "endpoint": "https://fcm.googleapis.com/fcm/send/c0ZQ6zaNZUE:APA91bFD58dKNnlMyZ1RJoA2Icq3Go53upODWus9gppZTCgtRdOqshC6MaeGo4nUxWyOrQMBg7ViqoOg2lDRvmMsTF19WHhq2dBIwksW3dB2iUbxRQ-KnNmuHONxEYguVXJeVjQfQ2jz", 
    "expirationTime": null, 
    "keys": { 
        "p256dh": "BGWm2oVIQtK1RXKMObiHyxZZ9xRyrhh395R93KcBlkd43URuibdVw6rRE_RjM4EFAuzr9J5hXLst3y8iw8NXqWw", 
        "auth": "9Vekgi_LwWYJScOi6GCEBA" 
    } 
};

push.sendNotification(pushSubscription, 'Hello from a shot of code!');